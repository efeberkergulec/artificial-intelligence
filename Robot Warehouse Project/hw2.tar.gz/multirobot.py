import gym
import gym_warehouse


def run_agent():
    # create the Gym environment
    env = gym.make('multirobot-warehouse-v0')

    while True:
        env.render()    # you can used this for printing the environment

        # sense
        s = env.look()

        # think
        # ...

        # act
        ob, rew, done = env.step([env.ACTION_UP,env.ACTION_LEFT,env.ACTION_LEFT,env.ACTION_WAIT])
        
        if done:
            break

    env.close()


if __name__ == "__main__":
    run_agent()


